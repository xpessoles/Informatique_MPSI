SELECT nom, prenom 
FROM PERSONNE, JOUE
WHERE id = idacteur;
