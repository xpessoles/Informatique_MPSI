SELECT * 
FROM personne ;
