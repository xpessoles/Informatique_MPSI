INSERT INTO personne VALUES(1, 'Kubrick', 'Stanley', date('1928-07-26'));
INSERT INTO personne VALUES(2, 'Spielberg', 'Steven', date('1946-12-18'));
INSERT INTO personne VALUES(3, 'Eastwood', 'Clint', date('1930-05-31'));
INSERT INTO personne VALUES(4, 'Cumberbatch', 'Benedict', date('1976-07-19'));
INSERT INTO personne VALUES(5, 'Freeman', 'Martin', date('1971-09-08'));
INSERT INTO personne VALUES(6, 'Leone', 'Sergio', date('1929-01-03'));
INSERT INTO personne VALUES(7, 'McGuigan', 'Paul', date('1963-09-19'));
INSERT INTO personne VALUES(8, 'Sellers', 'Peter', date('1925-09-08'));

