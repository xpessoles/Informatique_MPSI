SELECT idacteur /2 AS quotient, idacteur/2 AS reste
FROM JOUE
;
