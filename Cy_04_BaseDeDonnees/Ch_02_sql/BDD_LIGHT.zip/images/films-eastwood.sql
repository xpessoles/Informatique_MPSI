SELECT titre, date 
FROM FILM
WHERE idrealisateur = 3;
