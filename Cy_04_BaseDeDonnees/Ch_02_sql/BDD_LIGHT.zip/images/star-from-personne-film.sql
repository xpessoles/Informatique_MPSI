SELECT * FROM personne, film;
