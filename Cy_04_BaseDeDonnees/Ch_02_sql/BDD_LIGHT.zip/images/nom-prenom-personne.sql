SELECT nom, prenom 
FROM PERSONNE ;
