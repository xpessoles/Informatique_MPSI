SELECT CAST(idacteur AS FLOAT)/100 , (1.0*idacteur)/100 
FROM JOUE
;
