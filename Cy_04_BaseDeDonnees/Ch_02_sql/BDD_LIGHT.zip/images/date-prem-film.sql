SELECT MIN(date) AS 'date premier film' 
FROM FILM;
