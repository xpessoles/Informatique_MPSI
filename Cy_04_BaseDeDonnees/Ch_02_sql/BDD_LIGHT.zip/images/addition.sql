SELECT idacteur + idfilm + 42 AS total
FROM JOUE
;
